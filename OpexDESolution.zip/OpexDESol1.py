# -*- coding: utf-8 -*-
"""
Created on Thu Feb 18 12:11:43 2019

@author: Smruti_Panigrahi
"""


import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import mysql.connector

sql_conn = mysql.connector.connect(user='root', password='Infosys1',host='localhost',database='srdb')
if sql_conn.is_connected():
       db_Info = sql_conn.get_server_info()
       print("Connected to MySQL database... MySQL Server version on ",db_Info)

query = "SELECT * FROM outliers"
df = pd.read_sql(query, sql_conn)
df[df.columns]=df[df.columns].apply(pd.to_numeric,errors="coerce")
df.describe()

plt.boxplot(df["col14"])

q75,median, q25 = np.percentile(df["col14"], [75,50,25])
iqr = q75 - q25
print(iqr)
print(q75)
print(q25)
print("Median:" , median)

df["col14"].dtype

outlier = [] ;
i = 0 
for a in df["col14"]:
    if (a < (q25 - 1.5 * iqr)):
        outlier.append(a)
    elif (a > (q75 + 1.5 * iqr)):
        outlier.append(a)
outliers = np.array(outlier)

len(outliers)

outliers.dtype

np.savetxt("solutions/outlierDetected.txt", outliers , fmt="%d")

