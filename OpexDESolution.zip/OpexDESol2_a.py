# -*- coding: utf-8 -*-
"""
Created on Thu Feb 19 18:59:23 2019

@author: Smruti_Panigrahi
"""

import mysql.connector
import json
import sys

##Parse the Arguments 
filename = sys.argv[1]

##Read the JSON file passed in argument with --file tag
with open(filename) as complain:
    data=json.loads(complain.read())

keys = []
for row in data:
    for key in row.keys():
        if key not in keys:
            keys.append(key)
qry1 = """CREATE TABLE complains({0});""".format(", ".join(map(lambda key: "{0} TEXT".format(key), keys)))

cur.execute(qry1)
print("Table Created!!")

f = open("../solutions/sol2/insert_sol1.sql", "a")
f.write("USE srdb;" + '\n')
for row in data:
    columns = ', '.join("" + str(x).replace('/', '_') + "" for x in row.keys())
    values = ', '.join("'" + str(x).replace("'", '') + "'" for x in row.values())
    sql = "INSERT INTO %s ( %s ) VALUES ( %s );" % ('complains', columns, values)
    f = open("../solutions/sol2/insert_sol1.sql", "a")
    f.write(sql + '\n')
