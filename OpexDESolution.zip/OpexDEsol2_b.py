# -*- coding: utf-8 -*-
"""
Created on Thu Feb 19 19:48:21 2019

@author: Smruti_Panigrahi
"""
import json
import os

with open("complains.json") as complain:
    data=json.loads(complain.read())

keys = []
for row in data:
    for key in row.keys():
        if key not in keys:
            keys.append(key)
qry1 = """CREATE TABLE opex_json_hive({0}) ROW FORMAT SERDE 'com.cloudera.hive.serde.JSONSerDe';""".format(", ".join(map(lambda key: "{0} STRING".format(key), keys)))
f = open("solutions/sol2/insert_json.hql", "a")
f.write("USE opex;" + '\n')
f.write("add jar /hadoop/smruti/Hive/hive-serdes-1.0-SNAPSHOT.jar;" + '\n')
f.write(qry1 + '\n')
f.write("load data local inpath '/hadoop/smruti/Hive/complains.json' overwrite into table opex_json_hive;\n")