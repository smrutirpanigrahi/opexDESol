# -*- coding: utf-8 -*-
"""
Created on Thu Feb 21 20:28:41 2019

@author: Smruti_Panigrahi
"""
import sys
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer

#Read the filename from argument
filename = sys.argv[1]

#Open the file and read the documents terminated by newline "\n"
lines = open(filename, "r").read().split('\n')
#lines = [line.rstrip('\n') for line in lines]
lines = [x.strip() for x in lines] 

#CountVectorizer is used to Convert a collection of documents to a matrix of counts
vec = CountVectorizer()
X = vec.fit_transform(lines)
df = pd.DataFrame(X.toarray(), columns=vec.get_feature_names())

##Rename the index name to "para0", "para1"...
for i in range(len(lines)):
    df.rename(index={i: "para" + str(i)}, inplace=True)

##store the output to a text file(Tab separated)
outputFilepath= sys.argv[2] + filename
df.to_csv(outputFilepath, sep='\t')